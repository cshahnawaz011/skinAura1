import { Toaster } from "@/components/ui/toaster"
import { QueryClientProvider } from '@tanstack/react-query'
import { queryClientInstance } from '@/lib/query-client'
import { pagesConfig } from './pages.config'
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import PageNotFound from './lib/PageNotFound';
import OfflineIndicator from '@/components/OfflineIndicator';
import { useEffect } from 'react';
import { initializeCache } from '@/lib/cacheService';
import ProductAnalytics from './pages/ProductAnalytics';
import SmartScheduler from './pages/SmartScheduler';
import SkinDiary from './pages/SkinDiary';
import SkinGoals from './pages/SkinGoals';
import NutritionScanner from './pages/NutritionScanner';
import FaceYoga from './pages/FaceYoga';
import SkinDetox from './pages/SkinDetox';
import BeautyCalendar from './pages/BeautyCalendar';
import TravelSkincare from './pages/TravelSkincare';

import GlowChallenge from './pages/GlowChallenge';

import SkinAnalysisPage from './pages/SkinAnalysis';
import FacialHeatmap from './pages/FacialHeatmap';
import IngredientLibrary from './pages/IngredientLibrary';
import Diet from './pages/Diet';
import GlowDashboard from './pages/GlowDashboard';
import LifestyleInsights from './pages/LifestyleInsights';
import RoutineIntelligence from './pages/RoutineIntelligence';

import AdaptiveSkinMap from './pages/AdaptiveSkinMap';
import HormoneTracker from './pages/HormoneTracker';
import SkinRoutine from './pages/SkinRoutine';
import { AuthProvider, useAuth } from '@/lib/AuthContext';
import UserNotRegisteredError from '@/components/UserNotRegisteredError';

const { Pages, Layout, mainPage } = pagesConfig;
const mainPageKey = mainPage ?? Object.keys(Pages)[0];
const MainPage = mainPageKey ? Pages[mainPageKey] : <></>;

const LayoutWrapper = ({ children, currentPageName }) => Layout ?
  <Layout currentPageName={currentPageName}>{children}</Layout>
  : <>{children}</>;

const AuthenticatedApp = () => {
  const { isLoadingAuth, isLoadingPublicSettings, authError, navigateToLogin } = useAuth();

  // Show loading spinner while checking app public settings or auth
  if (isLoadingPublicSettings || isLoadingAuth) {
    return (
      <div className="fixed inset-0 flex items-center justify-center">
        <div className="w-8 h-8 border-4 border-slate-200 border-t-slate-800 rounded-full animate-spin"></div>
      </div>
    );
  }

  // Handle authentication errors
  if (authError) {
    if (authError.type === 'user_not_registered') {
      return <UserNotRegisteredError />;
    } else if (authError.type === 'auth_required') {
      // Redirect to login automatically
      navigateToLogin();
      return null;
    }
  }

  // Render the main app
  return (
    <Routes>
      <Route path="/" element={
        <LayoutWrapper currentPageName={mainPageKey}>
          <MainPage />
        </LayoutWrapper>
      } />
      {Object.entries(Pages).map(([path, Page]) => (
        <Route
          key={path}
          path={`/${path}`}
          element={
            <LayoutWrapper currentPageName={path}>
              <Page />
            </LayoutWrapper>
          }
        />
      ))}
      <Route path="/ProductAnalytics" element={<LayoutWrapper currentPageName="ProductAnalytics"><ProductAnalytics /></LayoutWrapper>} />
      <Route path="/SmartScheduler" element={<LayoutWrapper currentPageName="SmartScheduler"><SmartScheduler /></LayoutWrapper>} />
      <Route path="/SkinDiary" element={<LayoutWrapper currentPageName="SkinDiary"><SkinDiary /></LayoutWrapper>} />
      <Route path="/SkinGoals" element={<LayoutWrapper currentPageName="SkinGoals"><SkinGoals /></LayoutWrapper>} />
      <Route path="/NutritionScanner" element={<LayoutWrapper currentPageName="NutritionScanner"><NutritionScanner /></LayoutWrapper>} />
      <Route path="/FaceYoga" element={<LayoutWrapper currentPageName="FaceYoga"><FaceYoga /></LayoutWrapper>} />
      <Route path="/SkinDetox" element={<LayoutWrapper currentPageName="SkinDetox"><SkinDetox /></LayoutWrapper>} />
      <Route path="/BeautyCalendar" element={<LayoutWrapper currentPageName="BeautyCalendar"><BeautyCalendar /></LayoutWrapper>} />
      <Route path="/TravelSkincare" element={<LayoutWrapper currentPageName="TravelSkincare"><TravelSkincare /></LayoutWrapper>} />

      <Route path="/GlowChallenge" element={<LayoutWrapper currentPageName="GlowChallenge"><GlowChallenge /></LayoutWrapper>} />

      <Route path="/FacialHeatmap" element={<LayoutWrapper currentPageName="FacialHeatmap"><FacialHeatmap /></LayoutWrapper>} />
      <Route path="/IngredientLibrary" element={<LayoutWrapper currentPageName="IngredientLibrary"><IngredientLibrary /></LayoutWrapper>} />
      <Route path="/Diet" element={<LayoutWrapper currentPageName="Diet"><Diet /></LayoutWrapper>} />
      <Route path="/GlowDashboard" element={<LayoutWrapper currentPageName="GlowDashboard"><GlowDashboard /></LayoutWrapper>} />
      <Route path="/LifestyleInsights" element={<LayoutWrapper currentPageName="LifestyleInsights"><LifestyleInsights /></LayoutWrapper>} />
      <Route path="/RoutineIntelligence" element={<LayoutWrapper currentPageName="RoutineIntelligence"><RoutineIntelligence /></LayoutWrapper>} />

      <Route path="/AdaptiveSkinMap" element={<LayoutWrapper currentPageName="AdaptiveSkinMap"><AdaptiveSkinMap /></LayoutWrapper>} />
      <Route path="/SkinAnalysis" element={<LayoutWrapper currentPageName="SkinAnalysis"><SkinAnalysisPage /></LayoutWrapper>} />
      <Route path="/SkinRoutine" element={<LayoutWrapper currentPageName="SkinRoutine"><SkinRoutine /></LayoutWrapper>} />
      <Route path="/HormoneTracker" element={<LayoutWrapper currentPageName="HormoneTracker"><HormoneTracker /></LayoutWrapper>} />
      <Route path="*" element={<PageNotFound />} />
    </Routes>
  );
};


function App() {
  useEffect(() => {
    // Initialize cache on app load
    initializeCache().catch(err => console.error('Cache init failed:', err));
  }, []);

  return (
    <AuthProvider>
      <QueryClientProvider client={queryClientInstance}>
        <Router>
          <OfflineIndicator />
          <AuthenticatedApp />
        </Router>
        <Toaster />
      </QueryClientProvider>
    </AuthProvider>
  )
}

export default App